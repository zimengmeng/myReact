import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import { Carousel, WingBlank } from 'antd-mobile';
import { List, Flex } from 'antd-mobile';
import { getAllUsers } from '../../api/usermanger'
export default class Shouye extends Component {

    constructor(props) {
        super(props)
        this.state = {
            pwd: "",
            flag: false,
            flag1: true,
            userlist: ""
        }
    }

    clickHandle(e) {
        this.setState({
            pwd: e.target.value
        }, () => {
            let newPwd = this.state.pwd;
            if (newPwd === "123") {
                this.setState({
                    flag1: false,
                    flag: true
                })
            }

        })
    }

    componentDidMount() {
        getAllUsers().then((res) => {
            console.log(res.data.data)
            this.setState({
                userlist: res.data.data
            })
        })
    }
    render() {
        return (
            <div className="shouye">
                <div className="and">
                    <div className="sum">
                        100
                    </div>
                    <p>hi,2221寝室的美女们</p>
                    {
                        this.state.flag && <p className="p"><Link to="/user">管理用户</Link></p>
                    }
                    {
                        this.state.flag1 && <input placeholder="请输入密码" defaultValue={this.state.pwd} onBlur={(ev) => this.clickHandle(ev)} />
                    }
                </div>
                <div className="banner">
                    <WingBlank>
                        <Carousel className="my-carousel"
                            vertical={false}
                            dots={false}
                            dragging={false}
                            swiping={false}
                            autoplay
                            infinite
                        >
                            <div className="v-item">carousel 1</div>
                            <div className="v-item">carousel 2</div>
                            <div className="v-item">carousel 3</div>
                        </Carousel>
                    </WingBlank>
                </div>
                <List className="list">
                    {
                        this.state.userlist && this.state.userlist.map((item, key) => {
                            return <List.Item key={key}>

                                <Flex>
                                    <Flex.Item> <Link to={{ pathname: "/layout/detail", query: { item: item } }}>{item.username}</Link></Flex.Item>
                                    <Flex.Item>{item.userid}</Flex.Item>
                                </Flex>

                            </List.Item>
                        })
                    }
                </List>
            </div>
        )
    }
}
