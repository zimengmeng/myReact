import React, { Component } from 'react'

export default class Sum extends Component {
    render() {
        return (
            <div className="sum">
                <div className="and">100</div>
                <div className="list">
                    <p><span>姓名</span><span>个人总计</span><span>平均金额</span><span>应付</span><span>应收</span></p>
                </div>
            </div>
        )
    }
}
