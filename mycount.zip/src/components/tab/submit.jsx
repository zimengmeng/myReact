import React, { Component } from 'react'
import { DatePicker, InputItem, Button, Picker, List } from 'antd-mobile';
import { district } from 'antd-mobile-demo-data';
// const nowTimeStamp = Date.now();
// const now = new Date(nowTimeStamp);
// const utcNow = new Date(now.getTime() + (now.getTimezoneOffset() * 60000));

export default class Submit extends Component {
    state = {
        data: [],
        flag: false
    }
    render() {
        return (
            <div>
                <DatePicker
                    mode="date"
                    title="Select Date"
                    extra=""
                    value={this.state.date}
                    onChange={date => this.setState({ date })}
                >
                    <List.Item arrow="horizontal">时间</List.Item>
                </DatePicker>
                <Picker data={district} cols={1} className="forss">
                    <List.Item arrow="horizontal">姓名</List.Item>
                </Picker>
                <InputItem placeholder="请输入金额">金额</InputItem>
                <InputItem placeholder="请输入备注">用途备注</InputItem>
                <div className="but">
                    <div className="Button">
                        <Button type="primary">提交</Button>
                    </div>
                    <div className="Button">
                        <Button type="warning">清空</Button>
                    </div>
                </div>
            </div>
        )
    }
}
