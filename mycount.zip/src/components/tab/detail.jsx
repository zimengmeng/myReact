import React, { Component } from 'react'

export default class Detail extends Component {
    constructor(props) {
        super(props)
        this.state = {
            data: this.props.location.query.item
        }
    }
    render() {
        return (
            <div className="detail">
                <ul>
                    <li><p>用户名</p><span>钱数</span></li>
                    {this.state.data && <li><p>{this.state.data.username}</p><span>{this.state.data.moneybase}</span></li>}
                </ul>
            </div>
        )
    }
}
