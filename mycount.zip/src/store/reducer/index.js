import { combineReducers } from 'redux';
import { test } from './test'
import { usermanger } from './usermanger'
let reducer = combineReducers({
    test, usermanger
})
export default reducer;