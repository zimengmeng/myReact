import React, { Component } from 'react';
import Section from './components/section'

class App extends Component {
  render() {
    return (
      <div className="wrap">
        <Section></Section>
      </div>
    )

  }
}

export default App;
